These instructions are intended for a tournament organizer. In theory, you're reading this because
you've just extracted a zip file submitted to a tournament. If that's not your situation, go look at README.md
instead.

1. Install Java 8 or newer.
2. Reference the included `tournament.cfg` file as you would do with a plain python bot.

Advanced:

- It's fine to close and restart `.bat` while the framework is active.
- If there is a port conflict, you can modify both copies of `port.cfg`
to use a different one. There's one here and one in the bin folder.
